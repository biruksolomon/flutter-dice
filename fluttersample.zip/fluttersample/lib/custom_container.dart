import 'package:flutter/material.dart';
import 'package:hello_world/reusable_text.dart';

class CustomContainer extends StatelessWidget{
  @override
  Widget build(context){
    return Container(
     decoration: BoxDecoration(
       gradient: LinearGradient(
           colors: [
             Colors.black,
           Colors.black54
           ],
         begin: Alignment.topLeft,
         end: Alignment.bottomRight
       )
     ),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ReusableText('Central Text', 30, Colors.white),
            SizedBox(height: 20),
            Image.asset("assets/images/dice-3.png"),
            SizedBox(height: 20,),
            TextButton(onPressed: (){}, child: ReusableText("Click to Roll", 20, Colors.white))
          ],
        ),
      ),
    );
  }
}